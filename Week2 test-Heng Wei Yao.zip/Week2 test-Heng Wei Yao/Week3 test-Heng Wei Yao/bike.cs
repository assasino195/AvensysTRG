﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3_test_Heng_Wei_Yao
{
    interface bike
    {
        int speed { get; }
        int enginecapacity { get; }
        int torque { get; }
        void showbikeinfo();
       
    }
}
